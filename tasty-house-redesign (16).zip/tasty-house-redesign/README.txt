TASTY HOUSE — WEBSITE PACKAGE

OPEN
Extract this ZIP and open index.html in a modern browser. Keep its folders together.
No build or installation required. Upload folder contents to static hosting when ready.
This downloadable package does not itself replace the live website.

CURRENT FEATURES
45 menu entries: 36 individual food listings and 9 combos. All appear on one page.
Optional category filters, search, larger photographs and accessible order buttons.
English, Bengali and Russian names, details, combo contents and prices.
Bengali loading animation and initial menu on each visit.
Large language choices initially; selecting one reveals a compact dropdown with globe.
Saved cart between visits until checkout. Address is optional.
Continue to WhatsApp opens the order message, then clears cart/address and saved cart.
The customer must send the WhatsApp message and confirm with the restaurant.
WhatsApp/phone: +8801884535335.
Google Maps and directions links point to the restaurant's supplied location.
Free delivery wording remains limited to Green City, Elliron City and Ruppur.

BRANDED PHOTOGRAPHS
Tasty House logo added to all 45 food/combo images near a clear edge or corner.
Existing logos printed on combo glasses/tissues are retained.
Image framing uses contain so logos are not cut off in menu/cart/detail views.
Small WebP thumbnails load for menu/cart; larger versions load for item details.
Full assets: Menu-Images/*.webp. Thumbnails: Menu-Images/thumbs/*.webp.
Built-in imagegen was used to place the supplied restaurant logo with minimal food
obstruction, preserving dish appearance, counts, composition, lighting and existing
branding. Generated edits can have minor texture differences from the originals.

MENU NOTES
Original listings/prices retained, including two Buffalo listings (IDs 10 and 18).
Nobab-a-Dhaka added at Tk 850; no size was supplied, so none is claimed.
Sea Queen added at Tk 800, 12 inches / 31 cm, using the supplied photo.
Sea Combo photo now uses the supplied Sea Queen as reference, replacing the stand-in.
Party Combo: Tk 12,500; 16 pizzas, 50 glasses, 8L Coca-Cola and tissues.
Chicken Combo: Tk 3,250; 4 pizzas, 20 glasses, 2L Coca-Cola and tissues.
Sea Combo: Tk 4,200; 4 pizzas, 20 glasses, 3L Coca-Cola and tissues.
Beef Combo: Tk 8,900; 10 pizzas, 30 glasses, 4L Coca-Cola and tissues.
Exact included pizza lists are in the item detail views.
Combo images are illustrative compositions; cup stacks represent the listed quantity.

EDITING
menu-data.js: food and combo data in three languages.
app.js: language controls, filters, cart, checkout and UI text.
index.html: layout, initial loader, navigation, map/contact links.
style.css: layout, colours, responsive sizes and motion.
Logo/: supplied restaurant logo assets.
Update phone numbers in both index.html and app.js if needed.

VALIDATION
Menu data, translations, price calculations, optional-address checkout, cart reset,
language controls and image paths have been checked. Branded images inspected.
Browser visual testing and sending a live WhatsApp order have not been performed.

Photo display: standalone food images fill their original menu and cart frames, aligned to the top to retain branding. Combo compositions remain fully visible.
