TASTY HOUSE — COMPACT REDESIGN, VERSION 8

OPEN
Extract the ZIP, then open index.html in a modern browser. Keep all folders
together. No installation or build command is required.

CHANGES
- Larger food photos, names, prices and 48px-tall add buttons.
- Two roomy columns on desktop and larger single-column mobile cards.
- All 44 dishes appear immediately on one page. No Next buttons or page numbers.
- Optional sticky category filters and search; larger photo/name/price rows.
- Ingredients remain available by opening item details.
- Removed the tall hero and shortened contact/footer sections.
- Category navigation and search across dish names and ingredients.
- Bengali animated loading screen; Bengali default for first-time visitors.
- Returning visitors retain their selected language and saved cart.
- Loader ends when CSS and the menu app are ready, without waiting for all photos.
- After six seconds of incomplete loading, retry and direct WhatsApp options appear.
- Lightweight image shimmer while individual thumbnails load; reduced motion supported.
- All 39 menu/combination photos cleaned of Tasty House logos and promotional overlays.
- Restaurant logo retained in the site header.
- Small thumbnails for menu and cart; larger photos load only in item details.
- Only the first two thumbnails are requested eagerly; remaining photos use native
  lazy loading. Browser prefetch and viewport size determine initial transfer size.

CONTENT AND ORDERING
All 34 original menu listings and five combos retain their original prices,
ingredients and existing translations. The original duplicate Buffalo entries
remain (IDs 10 and 18). All nine combos now have English, Bengali and Russian names, contents and summaries.
Burger extra-patty pricing is preserved. Orders open in WhatsApp at
+8801884535335. Customers must send the message and confirm with the restaurant.
The cart is retained after WhatsApp opens. No payment/backend order system is included.
Delivery wording remains limited to Green City, Elliron City and Ruppur.

EDITING
index.html: layout, loader, header and contact links.
style.css: visual appearance and responsive layout.
menu-data.js: menu names, prices, ingredients and original translations.
app.js: interface translations, pagination, search, cart and WhatsApp checkout.
Menu-Images/: cleaned larger images.
Menu-Images/thumbs/: lightweight versions of the same images.
Logo/: restaurant logo.
If changing the phone number, update index.html and app.js.

IMAGE CLEANUP
Built-in AI image editing removed restaurant graphics from the existing photos.
Food identity, item counts and arrangement were visually reviewed. Covered areas
were reconstructed; edited images are not pixel-identical to the originals.
Prompt set: remove restaurant logos, slogans, delivery lettering and delivery
icons; reconstruct only covered background/food; preserve toppings, arrangement,
lighting and framing. For combos, preserve all food and bottle counts and bottle
branding, replacing restaurant branding with matching white background.

VALIDATION
JavaScript syntax checked. Automated checks passed for Bengali default, saved
language/cart, all 44 listings visible without pagination in three languages,
English/Bengali search, empty results, category filtering, burger prices,
WhatsApp destination/message, cart retention and loader/error fallback.
All local asset paths verified. All cleaned image assets visually inspected.
Browser visual/layout testing and live WhatsApp submission were not performed.

PUBLISHING
Upload this folder's contents to static hosting with index.html at its root.
Back up the current live website first. This package has not replaced the live site.

NEW MENU ITEM
Pizza Nobab-a-Dhaka, ৳850, added using the supplied photograph and ingredients.
Bengali, English and Russian text included. Size is not specified because it
was not provided. The new photo was resized and compressed, not AI edited.

FOUR NEW COMBOS
Party Combo: Tk 12,500. 16 pizzas, 50 glasses, 8L Coca-Cola and tissues.
Chicken Combo: Tk 3,250. 4 pizzas, 20 glasses, 2L Coca-Cola and tissues.
Sea Combo: Tk 4,200. 4 pizzas, 20 glasses, 3L Coca-Cola and tissues.
Beef Combo: Tk 8,900. 10 pizzas, 30 glasses, 4L Coca-Cola and tissues.
Complete pizza lists appear in each detail view in English, Bengali and Russian.
Pizza Sea Queen is included in the Sea Combo text. As requested, a second Norway
pizza represents its place in the illustrative photo. Sea Queen has not been
invented as a separately priced standalone menu item.
New combo photographs are AI-created compositions referenced to the existing
pizza photos, with restaurant branding printed on the cups and tissues. Glasses
are represented in stacks; the textual list specifies the exact included quantity.
Generated images are illustrative and are not documentation of a prepared order.
Prompt set: white seamless studio group photographs of each specified combo,
preserving pizza likeness and pizza count; Coca-Cola at stated volume; nested cups
and folded tissues with the supplied Tasty House logo; no floating logo or price.
Built-in imagegen used. Assets: Menu-Images/Combo-6.webp through Combo-9.webp and
matching lightweight thumbnails. Only imagery changes; existing food pricing stays.
Validation: four prices, pizza counts, trilingual lists and extras, Sea Queen search,
and combined new-combo cart total Tk 28,850 checked in the JavaScript harness.

LANGUAGE FIX
Translated the original five combos in menu, details and cart. Prices now use
the selected language locale. Brand artwork remains unchanged. All 44 names
and nine combo content lists verified in English, Bengali and Russian.

LOCATION
Added a prominent map link above the menu, desktop location navigation and a
location section with directions, the supplied Google Maps place link and call.
All location labels follow English/Bengali/Russian selection. No embedded map
is downloaded during page load. Coordinates 24.083095,89.0730038 were resolved
from the supplied Google Maps short link, which identifies Tasty House.
No street address or opening hours were assumed.
