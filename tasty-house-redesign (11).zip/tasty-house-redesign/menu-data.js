        const i18n = {
            en: {
                shopName: "Дом Вкуса | Tasty House",
                menuTitle: "Our Menu",
                menuSubtitle: "Fresh, delicious pizza made with love. Add items to cart and order via WhatsApp!",
                pizzas: "Pizzas",
                burgers: "Burgers",
                cart: "Cart",
                yourCart: "Your Cart",
                emptyCart: "Your cart is empty",
                total: "Total:",
                orderWhatsApp: "Order on WhatsApp",
                addToCart: "Add to Cart",
                back: "Back",
                size: "Size:",
                ingredients: "Ingredients:",
                addedToCart: "Added to Cart!",
                orderMessage: "I want to order",
                extraPatty: "Extra Patty",
                patty: "patty",
                patties: "patties",
                specialOffers: "Special Offers / Discount",
                comboSubtitle: "Save more with our combo deals",
                includes: "Includes:",
                pleaseConfirm: "Please confirm my order.",
                deliveryAddress: "Delivery Address:",
                addressPlaceholder: "Green City, Gate 2",
                deliveryNote: "🛵 Free delivery in Green City, Elliron City & Ruppur!",
                deliveryModalTitle: "Free Delivery!",
                remove: "Remove",
                footerTagline: "Fresh pizza & burgers in Ishwardi. Order easily via WhatsApp."
            },
            ru: {
                shopName: "Дом Вкуса | Tasty House",
                menuTitle: "Наше Меню",
                menuSubtitle: "Свежая, вкусная пицца с любовью. Добавьте в корзину и закажите через WhatsApp!",
                pizzas: "Пиццы",
                burgers: "Бургеры",
                cart: "Корзина",
                yourCart: "Ваша Корзина",
                emptyCart: "Ваша корзина пуста",
                total: "Итого:",
                orderWhatsApp: "Заказать в WhatsApp",
                addToCart: "В Корзину",
                back: "Назад",
                size: "Размер:",
                ingredients: "Ингредиенты:",
                addedToCart: "Добавлено в корзину!",
                orderMessage: "Я хочу заказать",
                extraPatty: "Доп. котлета",
                patty: "котлета",
                patties: "котлеты",
                specialOffers: "Специальные предложения / Скидки",
                comboSubtitle: "Экономьте больше с нашими комбо",
                includes: "Включает:",
                pleaseConfirm: "Пожалуйста, подтвердите мой заказ.",
                deliveryAddress: "Адрес доставки:",
                addressPlaceholder: "Green City, Gate 2",
                deliveryNote: "🛵 Бесплатная доставка в Грин-Сити, Эллирон-Сити и Руппур!",
                deliveryModalTitle: "Бесплатная доставка!",
                remove: "Удалить",
                footerTagline: "Свежая пицца и бургеры в Ишварди. Заказывайте легко через WhatsApp."
            },
            bn: {
                shopName: "Дом Вкуса | Tasty House",
                menuTitle: "আমাদের মেনু",
                menuSubtitle: "ভালবাসা দিয়ে তৈরি তাজা, সুস্বাদু পিজ্জা। কার্টে যোগ করুন এবং WhatsApp-এ অর্ডার করুন!",
                pizzas: "পিজ্জা",
                burgers: "বার্গার",
                cart: "কার্ট",
                yourCart: "আপনার কার্ট",
                emptyCart: "আপনার কার্ট খালি",
                total: "মোট:",
                orderWhatsApp: "WhatsApp-এ অর্ডার করুন",
                addToCart: "কার্টে যোগ করুন",
                back: "পেছনে",
                size: "সাইজ:",
                ingredients: "উপাদান:",
                addedToCart: "কার্টে যোগ করা হয়েছে!",
                orderMessage: "আমি অর্ডার করতে চাই",
                extraPatty: "এক্সট্রা প্যাটি",
                patty: "প্যাটি",
                patties: "প্যাটি",
                specialOffers: "বিশেষ অফার / ডিসকাউন্ট",
                comboSubtitle: "আমাদের কম্বো ডিলে আরও বাঁচান",
                includes: "যা আছে:",
                pleaseConfirm: "অনুগ্রহ করে আমার অর্ডার নিশ্চিত করুন।",
                deliveryAddress: "ডেলিভারি ঠিকানা:",
                addressPlaceholder: "Green City, Gate 2",
                deliveryNote: "🛵 গ্রিন সিটি, এলিরন সিটি ও রূপপুরে বিনামূল্যে ডেলিভারি!",
                deliveryModalTitle: "ফ্রি ডেলিভারি!",
                remove: "সরান",
                footerTagline: "ইশ্বরদীতে তাজা পিজ্জা ও বার্গার। WhatsApp-এ সহজে অর্ডার করুন।"
            }
        };

        const comboData = [
  {
    "id": "c1",
    "name": "Royal Combo",
    "price": 3600,
    "items": "Pizza Burger, Pizza Western, Pizza New York, Pizza Karbanara, Pizza Capicciza Cream, Pizza Margarita + 2 Colas",
    "image": "Menu-Images/Combo-1.webp",
    "names": {
      "en": "Royal Combo",
      "bn": "রয়্যাল কম্বো",
      "ru": "Королевское комбо"
    },
    "contents": [
      {
        "en": "Pizza Burger",
        "ru": "Пицца Бургер",
        "bn": "পিজ্জা বার্গার"
      },
      {
        "en": "Pizza Western",
        "ru": "Пицца Вестерн",
        "bn": "পিজ্জা ওয়েস্টার্ন"
      },
      {
        "en": "Pizza New York",
        "ru": "Пицца Нью-Йорк",
        "bn": "পিজ্জা নিউ ইয়র্ক"
      },
      {
        "en": "Pizza Karbanara",
        "ru": "Пицца Карбонара",
        "bn": "পিজ্জা কার্বোনারা"
      },
      {
        "en": "Pizza Capicciza Cream",
        "ru": "Пицца Капричоза Сливочная",
        "bn": "পিজ্জা কাপ্রিচোজা ক্রিম"
      },
      {
        "en": "Pizza Margarita",
        "ru": "Пицца Маргарита",
        "bn": "পিজ্জা মার্গারিটা"
      }
    ],
    "extras": {
      "en": "2 colas",
      "bn": "২টি কোলা",
      "ru": "Кола — 2 шт."
    },
    "summary": {
      "en": "6 pizzas · 2 colas",
      "bn": "৬টি পিজ্জা · ২টি কোলা",
      "ru": "Пиццы — 6 · Кола — 2 шт."
    }
  },
  {
    "id": "c2",
    "name": "Friends Combo",
    "price": 870,
    "items": "2 Beef Burgers + 2 Chicken Burgers + 1 Cola",
    "image": "Menu-Images/Combo-2.webp",
    "names": {
      "en": "Friends Combo",
      "bn": "ফ্রেন্ডস কম্বো",
      "ru": "Комбо для друзей"
    },
    "contents": [
      {
        "en": "Beef Burger",
        "ru": "Биф Бургер",
        "bn": "বিফ বার্গার"
      },
      {
        "en": "Beef Burger",
        "ru": "Биф Бургер",
        "bn": "বিফ বার্গার"
      },
      {
        "en": "Chicken Burger",
        "ru": "Чикен Бургер",
        "bn": "চিকেন বার্গার"
      },
      {
        "en": "Chicken Burger",
        "ru": "Чикен Бургер",
        "bn": "চিকেন বার্গার"
      }
    ],
    "extras": {
      "en": "1 cola",
      "bn": "১টি কোলা",
      "ru": "Кола — 1 шт."
    },
    "summary": {
      "en": "4 burgers · 1 cola",
      "bn": "৪টি বার্গার · ১টি কোলা",
      "ru": "Бургеры — 4 · Кола — 1 шт."
    }
  },
  {
    "id": "c3",
    "name": "Mega Combo",
    "price": 2400,
    "items": "Pizza Bavaria + Pizza Pepperoni + Pizza Mama Mia + 1 Cola",
    "image": "Menu-Images/Combo-3.webp",
    "names": {
      "en": "Mega Combo",
      "bn": "মেগা কম্বো",
      "ru": "Мега-комбо"
    },
    "contents": [
      {
        "en": "Pizza Bavaria",
        "ru": "Пицца Баварская",
        "bn": "পিজ্জা বাভারিয়া"
      },
      {
        "en": "Pizza Pepperoni",
        "ru": "Пицца Пепперони",
        "bn": "পিজ্জা পেপারোনি"
      },
      {
        "en": "Pizza Mama Mia",
        "ru": "Пицца Мама Мия",
        "bn": "পিজ্জা মামা মিয়া"
      }
    ],
    "extras": {
      "en": "1 cola",
      "bn": "১টি কোলা",
      "ru": "Кола — 1 шт."
    },
    "summary": {
      "en": "3 pizzas · 1 cola",
      "bn": "৩টি পিজ্জা · ১টি কোলা",
      "ru": "Пиццы — 3 · Кола — 1 шт."
    }
  },
  {
    "id": "c4",
    "name": "Tasty Combo",
    "price": 1300,
    "items": "Pizza Burger + Pizza Washington + 1 Cola",
    "image": "Menu-Images/Combo-4.webp",
    "names": {
      "en": "Tasty Combo",
      "bn": "টেস্টি কম্বো",
      "ru": "Тейсти-комбо"
    },
    "contents": [
      {
        "en": "Pizza Burger",
        "ru": "Пицца Бургер",
        "bn": "পিজ্জা বার্গার"
      },
      {
        "en": "Pizza Washington",
        "ru": "Пицца Вашингтон",
        "bn": "পিজ্জা ওয়াশিংটন"
      }
    ],
    "extras": {
      "en": "1 cola",
      "bn": "১টি কোলা",
      "ru": "Кола — 1 шт."
    },
    "summary": {
      "en": "2 pizzas · 1 cola",
      "bn": "২টি পিজ্জা · ১টি কোলা",
      "ru": "Пиццы — 2 · Кола — 1 шт."
    }
  },
  {
    "id": "c5",
    "name": "Supreme Combo",
    "price": 5800,
    "items": "Pizza New York, Pizza Burger, Pizza Capichoza Tomato, Pizza Capicciza Cream, Pizza Washington, Pizza Karbanara, Pizza Margarita, Pizza Kalzone + 4 Colas",
    "image": "Menu-Images/Combo-5.webp",
    "names": {
      "en": "Supreme Combo",
      "bn": "সুপ্রিম কম্বো",
      "ru": "Суприм-комбо"
    },
    "contents": [
      {
        "en": "Pizza New York",
        "ru": "Пицца Нью-Йорк",
        "bn": "পিজ্জা নিউ ইয়র্ক"
      },
      {
        "en": "Pizza Burger",
        "ru": "Пицца Бургер",
        "bn": "পিজ্জা বার্গার"
      },
      {
        "en": "Pizza Capichoza Tometo",
        "ru": "Пицца Капричоза Томатная",
        "bn": "পিজ্জা কাপ্রিচোজা টমেটো"
      },
      {
        "en": "Pizza Capicciza Cream",
        "ru": "Пицца Капричоза Сливочная",
        "bn": "পিজ্জা কাপ্রিচোজা ক্রিম"
      },
      {
        "en": "Pizza Washington",
        "ru": "Пицца Вашингтон",
        "bn": "পিজ্জা ওয়াশিংটন"
      },
      {
        "en": "Pizza Karbanara",
        "ru": "Пицца Карбонара",
        "bn": "পিজ্জা কার্বোনারা"
      },
      {
        "en": "Pizza Margarita",
        "ru": "Пицца Маргарита",
        "bn": "পিজ্জা মার্গারিটা"
      },
      {
        "en": "Pizza Kalzone (Closed)",
        "ru": "Пицца Кальцоне (Закрытая)",
        "bn": "পিজ্জা ক্যালজোন (বন্ধ)"
      }
    ],
    "extras": {
      "en": "4 colas",
      "bn": "৪টি কোলা",
      "ru": "Кола — 4 шт."
    },
    "summary": {
      "en": "8 pizzas · 4 colas",
      "bn": "৮টি পিজ্জা · ৪টি কোলা",
      "ru": "Пиццы — 8 · Кола — 4 шт."
    }
  },
  {
    "id": "c6",
    "name": "Party Combo",
    "names": {
      "en": "Party Combo",
      "bn": "পার্টি কম্বো",
      "ru": "Комбо для вечеринки"
    },
    "price": 12500,
    "items": "Pizza Bavaria, Pizza Capichoza Tometo, Pizza Mama Mia, Pizza Margarita, Pizza De-Checo, Pizza Merinara, Pizza Norway, Pizza Kalzone (Closed), Pizza Burger, Pizza Sausages Carnival, Pizza Western, Pizza Spicy BBQ, Pizza Meaty Mashroom, Pizza Meat Temptation, Pizza Continental, Pizza Marseleza + 50 glasses, 8 litres Coca-Cola and tissues",
    "image": "Menu-Images/Combo-6.webp",
    "contents": [
      {
        "en": "Pizza Bavaria",
        "ru": "Пицца Баварская",
        "bn": "পিজ্জা বাভারিয়া"
      },
      {
        "en": "Pizza Capichoza Tometo",
        "ru": "Пицца Капричоза Томатная",
        "bn": "পিজ্জা কাপ্রিচোজা টমেটো"
      },
      {
        "en": "Pizza Mama Mia",
        "ru": "Пицца Мама Мия",
        "bn": "পিজ্জা মামা মিয়া"
      },
      {
        "en": "Pizza Margarita",
        "ru": "Пицца Маргарита",
        "bn": "পিজ্জা মার্গারিটা"
      },
      {
        "en": "Pizza De-Checo",
        "ru": "Пицца Де-Чеко",
        "bn": "পিজ্জা ডে-চেকো"
      },
      {
        "en": "Pizza Merinara",
        "ru": "Пицца Маринара",
        "bn": "পিজ্জা মেরিনারা"
      },
      {
        "en": "Pizza Norway",
        "ru": "Пицца Норвежская",
        "bn": "পিজ্জা নরওয়ে"
      },
      {
        "en": "Pizza Kalzone (Closed)",
        "ru": "Пицца Кальцоне (Закрытая)",
        "bn": "পিজ্জা ক্যালজোন (বন্ধ)"
      },
      {
        "en": "Pizza Burger",
        "ru": "Пицца Бургер",
        "bn": "পিজ্জা বার্গার"
      },
      {
        "en": "Pizza Sausages Carnival",
        "ru": "Пицца Карнавал Колбасок",
        "bn": "পিজ্জা সসেজ কার্নিভাল"
      },
      {
        "en": "Pizza Western",
        "ru": "Пицца Вестерн",
        "bn": "পিজ্জা ওয়েস্টার্ন"
      },
      {
        "en": "Pizza Spicy BBQ",
        "ru": "Пицца Острый BBQ",
        "bn": "পিজ্জা স্পাইসি বারবিকিউ"
      },
      {
        "en": "Pizza Meaty Mashroom",
        "ru": "Пицца Мясная с Грибами",
        "bn": "পিজ্জা মিটি মাশরুম"
      },
      {
        "en": "Pizza Meat Temptation",
        "ru": "Пицца Искушение Мясом",
        "bn": "পিজ্জা মিট টেম্পটেশন"
      },
      {
        "en": "Pizza Continental",
        "ru": "Пицца Континенталь",
        "bn": "পিজ্জা কন্টিনেন্টাল"
      },
      {
        "en": "Pizza Marseleza",
        "ru": "Пицца Марселеза",
        "bn": "পিজ্জা মার্সেলেজা"
      }
    ],
    "extras": {
      "en": "50 glasses, 8 litres Coca-Cola and tissues",
      "bn": "৫০টি গ্লাস, ৮ লিটার কোকা-কোলা ও টিস্যু",
      "ru": "50 стаканов, 8 л Coca-Cola и салфетки"
    },
    "summary": {
      "en": "16 pizzas · 8L Coca-Cola",
      "bn": "১৬টি পিজ্জা · ৮ লিটার কোকা-কোলা",
      "ru": "16 пиццы · 8 л Coca-Cola"
    },
    "illustrative": false
  },
  {
    "id": "c7",
    "name": "Chicken Combo",
    "names": {
      "en": "Chicken Combo",
      "bn": "চিকেন কম্বো",
      "ru": "Куриное комбо"
    },
    "price": 3250,
    "items": "Pizza Buffalo, Pizza Spicy BBQ, Pizza Mexican Vegetable, Pizza Continental + 20 glasses, 2 litres Coca-Cola and tissues",
    "image": "Menu-Images/Combo-7.webp",
    "contents": [
      {
        "en": "Pizza Buffalo",
        "ru": "Пицца Баффало",
        "bn": "পিজ্জা বাফেলো"
      },
      {
        "en": "Pizza Spicy BBQ",
        "ru": "Пицца Острый BBQ",
        "bn": "পিজ্জা স্পাইসি বারবিকিউ"
      },
      {
        "en": "Pizza Mexican Vegetable",
        "ru": "Пицца Мексиканская Овощная",
        "bn": "পিজ্জা মেক্সিকান ভেজিটেবল"
      },
      {
        "en": "Pizza Continental",
        "ru": "Пицца Континенталь",
        "bn": "পিজ্জা কন্টিনেন্টাল"
      }
    ],
    "extras": {
      "en": "20 glasses, 2 litres Coca-Cola and tissues",
      "bn": "২০টি গ্লাস, ২ লিটার কোকা-কোলা ও টিস্যু",
      "ru": "20 стаканов, 2 л Coca-Cola и салфетки"
    },
    "summary": {
      "en": "4 pizzas · 2L Coca-Cola",
      "bn": "৪টি পিজ্জা · ২ লিটার কোকা-কোলা",
      "ru": "4 пиццы · 2 л Coca-Cola"
    },
    "illustrative": false
  },
  {
    "id": "c8",
    "name": "Sea Combo",
    "names": {
      "en": "Sea Combo",
      "bn": "সি কম্বো",
      "ru": "Морское комбо"
    },
    "price": 4200,
    "items": "Pizza Norway, Pizza Merinara, Pizza Sea Queen, Pizza Ocen Star + 20 glasses, 3 litres Coca-Cola and tissues",
    "image": "Menu-Images/Combo-8.webp",
    "contents": [
      {
        "en": "Pizza Norway",
        "ru": "Пицца Норвежская",
        "bn": "পিজ্জা নরওয়ে"
      },
      {
        "en": "Pizza Merinara",
        "ru": "Пицца Маринара",
        "bn": "পিজ্জা মেরিনারা"
      },
      {
        "en": "Pizza Sea Queen",
        "bn": "পিজ্জা সি কুইন",
        "ru": "Пицца Си Куин"
      },
      {
        "en": "Pizza Ocen Star",
        "ru": "Пицца Океан Стар",
        "bn": "পিজ্জা ওশেন স্টার"
      }
    ],
    "extras": {
      "en": "20 glasses, 3 litres Coca-Cola and tissues",
      "bn": "২০টি গ্লাস, ৩ লিটার কোকা-কোলা ও টিস্যু",
      "ru": "20 стаканов, 3 л Coca-Cola и салфетки"
    },
    "summary": {
      "en": "4 pizzas · 3L Coca-Cola",
      "bn": "৪টি পিজ্জা · ৩ লিটার কোকা-কোলা",
      "ru": "4 пиццы · 3 л Coca-Cola"
    },
    "illustrative": false
  },
  {
    "id": "c9",
    "name": "Beef Combo",
    "names": {
      "en": "Beef Combo",
      "bn": "বিফ কম্বো",
      "ru": "Комбо с говядиной"
    },
    "price": 8900,
    "items": "Pizza Tasty House, Pizza Nobab-a-Dhaka, Pizza Beef Blaster, Pizza Meaty Mashroom, Pizza Meat, Pizza 4 Meat, Pizza Meat Temptation, Pizza De-Checo, Pizza Karbanara, Pizza Boss + 30 glasses, 4 litres Coca-Cola and tissues",
    "image": "Menu-Images/Combo-9.webp",
    "contents": [
      {
        "en": "Pizza Tasty House",
        "ru": "Пицца Тасти Хаус",
        "bn": "পিজ্জা টেস্টি হাউস"
      },
      {
        "en": "Pizza Nobab-a-Dhaka",
        "ru": "Пицца Нобаб-а-Дакка",
        "bn": "পিজ্জা নবাব-এ-ঢাকা"
      },
      {
        "en": "Pizza Beef Blaster",
        "ru": "Пицца Биф Бластер",
        "bn": "পিজ্জা বিফ ব্লাস্টার"
      },
      {
        "en": "Pizza Meaty Mashroom",
        "ru": "Пицца Мясная с Грибами",
        "bn": "পিজ্জা মিটি মাশরুম"
      },
      {
        "en": "Pizza Meat",
        "ru": "Пицца Мясная",
        "bn": "পিজ্জা মিট"
      },
      {
        "en": "Pizza 4 Meat",
        "ru": "Пицца 4 Мяса",
        "bn": "পিজ্জা ৪ মিট"
      },
      {
        "en": "Pizza Meat Temptation",
        "ru": "Пицца Искушение Мясом",
        "bn": "পিজ্জা মিট টেম্পটেশন"
      },
      {
        "en": "Pizza De-Checo",
        "ru": "Пицца Де-Чеко",
        "bn": "পিজ্জা ডে-চেকো"
      },
      {
        "en": "Pizza Karbanara",
        "ru": "Пицца Карбонара",
        "bn": "পিজ্জা কার্বোনারা"
      },
      {
        "en": "Pizza Boss",
        "ru": "Пицца Босс",
        "bn": "পিজ্জা বস"
      }
    ],
    "extras": {
      "en": "30 glasses, 4 litres Coca-Cola and tissues",
      "bn": "৩০টি গ্লাস, ৪ লিটার কোকা-কোলা ও টিস্যু",
      "ru": "30 стаканов, 4 л Coca-Cola и салфетки"
    },
    "summary": {
      "en": "10 pizzas · 4L Coca-Cola",
      "bn": "১০টি পিজ্জা · ৪ লিটার কোকা-কোলা",
      "ru": "10 пиццы · 4 л Coca-Cola"
    },
    "illustrative": false
  }
];

        const menuData = [
  {
    "id": 1,
    "price": 850,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza De-Checo",
      "ru": "Пицца Де-Чеко",
      "bn": "পিজ্জা ডে-চেকো"
    },
    "ingredients": {
      "en": "Mixed sauce, mushrooms, chicken mortadella, beef.",
      "ru": "Смешанный соус, грибы, куриная мортаделла, говядина.",
      "bn": "মিশ্র সস, মাশরুম, চিকেন মর্তাদেলা, গরুর মাংস।"
    }
  },
  {
    "id": 2,
    "price": 850,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Continental",
      "ru": "Пицца Континенталь",
      "bn": "পিজ্জা কন্টিনেন্টাল"
    },
    "ingredients": {
      "en": "Tomato sauce, chicken, tomato, cucumber, jalapeño, pineapple, onion, burger sauce, mozzarella cheese.",
      "ru": "Томатный соус, курица, помидор, огурец, халапеньо, ананас, лук, бургерный соус, сыр моцарелла.",
      "bn": "টমেটো সস, মুরগির মাংস, টমেটো, শসা, জালাপেনো, আনারস, পেঁয়াজ, বার্গার সস, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 3,
    "price": 750,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Hawaiin",
      "ru": "Пицца Гавайская",
      "bn": "পিজ্জা হাওয়াইয়ান"
    },
    "ingredients": {
      "en": "Pineapple, ham, corn, mozzarella cheese.",
      "ru": "Ананас, ветчина, кукуруза, сыр моцарелла.",
      "bn": "আনারস, হ্যাম, ভুট্টা, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 4,
    "price": 700,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza New York",
      "ru": "Пицца Нью-Йорк",
      "bn": "পিজ্জা নিউ ইয়র্ক"
    },
    "ingredients": {
      "en": "Sauce, bacon, pepperoni, BBQ sauce, mozzarella cheese.",
      "ru": "Соус, бекон, пепперони, соус барбекю, сыр моцарелла.",
      "bn": "সস, বেকন, পেপারোনি, বারবিকিউ সস, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 5,
    "price": 650,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Kalzone (Closed)",
      "ru": "Пицца Кальцоне (Закрытая)",
      "bn": "পিজ্জা ক্যালজোন (বন্ধ)"
    },
    "ingredients": {
      "en": "Ham, mushrooms, cream, mozzarella cheese.",
      "ru": "Ветчина, грибы, сливки, сыр моцарелла.",
      "bn": "হ্যাম, মাশরুম, ক্রিম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 6,
    "price": 650,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Capichoza Tometo",
      "ru": "Пицца Капричоза Томатная",
      "bn": "পিজ্জা কাপ্রিচোজা টমেটো"
    },
    "ingredients": {
      "en": "Ham, mushrooms, mozzarella cheese.",
      "ru": "Ветчина, грибы, сыр моцарелла.",
      "bn": "হ্যাম, মাশরুম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 7,
    "price": 650,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Karbanara",
      "ru": "Пицца Карбонара",
      "bn": "পিজ্জা কার্বোনারা"
    },
    "ingredients": {
      "en": "Bacon, cream, mozzarella cheese.",
      "ru": "Бекон, сливки, сыр моцарелла.",
      "bn": "বেকন, ক্রিম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 8,
    "price": 850,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Meaty Mashroom",
      "ru": "Пицца Мясная с Грибами",
      "bn": "পিজ্জা মিটি মাশরুম"
    },
    "ingredients": {
      "en": "Sauce, mayonnaise, salami, boiled beef, corn, mozzarella cheese.",
      "ru": "Соус, майонез, салями, отварная говядина, кукуруза, сыр моцарелла.",
      "bn": "সস, মেয়োনেজ, সালামি, সিদ্ধ গরুর মাংস, ভুট্টা, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 9,
    "price": 1200,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza 4 Meat",
      "ru": "Пицца 4 Мяса",
      "bn": "পিজ্জা ৪ মিট"
    },
    "ingredients": {
      "en": "Sauce, mayonnaise, BBQ chicken, boiled beef, salami, sausages, tomatoes, mozzarella cheese.",
      "ru": "Соус, майонез, курица барбекю, отварная говядина, салями, колбаски, помидоры, сыр моцарелла.",
      "bn": "সস, মেয়োনেজ, বারবিকিউ চিকেন, সিদ্ধ গরুর মাংস, সালামি, সসেজ, টমেটো, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 10,
    "price": 780,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Buffalo",
      "ru": "Пицца Баффало",
      "bn": "পিজ্জা বাফেলো"
    },
    "ingredients": {
      "en": "BBQ chicken, sauce, mushrooms, tomato, cheese.",
      "ru": "Курица барбекю, соус, грибы, помидор, сыр.",
      "bn": "বারবিকিউ চিকেন, সস, মাশরুম, টমেটো, চিজ।"
    }
  },
  {
    "id": 11,
    "price": 800,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Mama Mia",
      "ru": "Пицца Мама Мия",
      "bn": "পিজ্জা মামা মিয়া"
    },
    "ingredients": {
      "en": "Ham, mushrooms, salami, mozzarella cheese.",
      "ru": "Ветчина, грибы, салями, сыр моцарелла.",
      "bn": "হ্যাম, মাশরুম, সালামি, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 12,
    "price": 950,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Beef Blaster",
      "ru": "Пицца Биф Бластер",
      "bn": "পিজ্জা বিফ ব্লাস্টার"
    },
    "ingredients": {
      "en": "Pepperoni, beef, sausages, tomato, BBQ sauce, bell pepper, jalapeño, mozzarella cheese.",
      "ru": "Пепперони, говядина, колбаски, помидор, соус барбекю, болгарский перец, халапеньо, сыр моцарелла.",
      "bn": "পেপারোনি, গরুর মাংস, সসেজ, টমেটো, বারবিকিউ সস, ক্যাপসিকাম, জালাপেনো, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 13,
    "price": 1400,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Ocen Star",
      "ru": "Пицца Океан Стар",
      "bn": "পিজ্জা ওশেন স্টার"
    },
    "ingredients": {
      "en": "Mushrooms, salmon, shrimp, squid, cream, mozzarella cheese.",
      "ru": "Грибы, лосось, креветки, кальмар, сливки, сыр моцарелла.",
      "bn": "মাশরুম, স্যালমন, চিংড়ি, স্কুইড, ক্রিম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 14,
    "price": 1000,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Norway",
      "ru": "Пицца Норвежская",
      "bn": "পিজ্জা নরওয়ে"
    },
    "ingredients": {
      "en": "Salmon, cream, mozzarella cheese.",
      "ru": "Лосось, сливки, сыр моцарелла.",
      "bn": "স্যালমন, ক্রিম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 15,
    "price": 850,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Tasty House",
      "ru": "Пицца Тасти Хаус",
      "bn": "পিজ্জা টেস্টি হাউস"
    },
    "ingredients": {
      "en": "Beef, tomatoes, jalapeño, mozzarella cheese.",
      "ru": "Говядина, помидоры, халапеньо, сыр моцарелла.",
      "bn": "গরুর মাংস, টমেটো, জালাপেনো, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 16,
    "price": 650,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Washington",
      "ru": "Пицца Вашингтон",
      "bn": "পিজ্জা ওয়াশিংটন"
    },
    "ingredients": {
      "en": "Salami, tomatoes, burger sauce, mozzarella cheese.",
      "ru": "Салями, помидоры, бургерный соус, сыр моцарелла.",
      "bn": "সালামি, টমেটো, বার্গার সস, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 17,
    "price": 850,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Bavaria",
      "ru": "Пицца Баварская",
      "bn": "পিজ্জা বাভারিয়া"
    },
    "ingredients": {
      "en": "Salami, pepperoni, sausages, onion, sauce, mozzarella cheese.",
      "ru": "Салями, пепперони, колбаски, лук, соус, сыр моцарелла.",
      "bn": "সালামি, পেপারোনি, সসেজ, পেঁয়াজ, সস, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 18,
    "price": 780,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Buffalo",
      "ru": "Пицца Баффало",
      "bn": "পিজ্জা বাফেলো"
    },
    "ingredients": {
      "en": "BBQ chicken, sauce, mushrooms, tomato, cheese.",
      "ru": "Курица барбекю, соус, грибы, помидор, сыр.",
      "bn": "বারবিকিউ চিকেন, সস, মাশরুম, টমেটো, চিজ।"
    }
  },
  {
    "id": 19,
    "price": 750,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Mexican Vegetable",
      "ru": "Пицца Мексиканская Овощная",
      "bn": "পিজ্জা মেক্সিকান ভেজিটেবল"
    },
    "ingredients": {
      "en": "Mixed sauce, mushrooms, onion, tomato, jalapeño, corn, mozzarella cheese.",
      "ru": "Смешанный соус, грибы, лук, помидор, халапеньо, кукуруза, сыр моцарелла.",
      "bn": "মিশ্র সস, মাশরুম, পেঁয়াজ, টমেটো, জালাপেনো, ভুট্টা, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 20,
    "price": 250,
    "size": "",
    "names": {
      "en": "Beef Burger",
      "ru": "Биф Бургер",
      "bn": "বিফ বার্গার"
    },
    "ingredients": {
      "en": "Beef patty, onion, tomatoes, pickled cucumbers, mozzarella cheese.",
      "ru": "Говяжья котлета, лук, помидоры, маринованные огурцы, сыр моцарелла.",
      "bn": "বিফ প্যাটি, পেঁয়াজ, টমেটো, আচারি শসা, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 21,
    "price": 200,
    "size": "",
    "names": {
      "en": "Chicken Burger",
      "ru": "Чикен Бургер",
      "bn": "চিকেন বার্গার"
    },
    "ingredients": {
      "en": "Chicken patty, onion, tomatoes, pickled cucumbers, mozzarella cheese.",
      "ru": "Куриная котлета, лук, помидоры, маринованные огурцы, сыр моцарелла.",
      "bn": "চিকেন প্যাটি, পেঁয়াজ, টমেটো, আচারি শসা, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 22,
    "price": 600,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Margarita",
      "ru": "Пицца Маргарита",
      "bn": "পিজ্জা মার্গারিটা"
    },
    "ingredients": {
      "en": "Basil, sauce, tomatoes, mozzarella cheese.",
      "ru": "Базилик, соус, помидоры, сыр моцарелла.",
      "bn": "তুলসী পাতা, সস, টমেটো, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 23,
    "price": 650,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Burger",
      "ru": "Пицца Бургер",
      "bn": "পিজ্জা বার্গার"
    },
    "ingredients": {
      "en": "Sausages, pickled onion, burger sauce, tomato, mozzarella cheese.",
      "ru": "Колбаски, маринованный лук, бургерный соус, помидор, сыр моцарелла.",
      "bn": "সসেজ, আচারি পেঁয়াজ, বার্গার সস, টমেটো, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 24,
    "price": 800,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Pepperoni",
      "ru": "Пицца Пепперони",
      "bn": "পিজ্জা পেপারোনি"
    },
    "ingredients": {
      "en": "Pepperoni, bacon, tomato, sauce, mozzarella cheese.",
      "ru": "Пепперони, бекон, помидор, соус, сыр моцарелла.",
      "bn": "পেপারোনি, বেকন, টমেটো, সস, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 25,
    "price": 800,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Merinara",
      "ru": "Пицца Маринара",
      "bn": "পিজ্জা মেরিনারা"
    },
    "ingredients": {
      "en": "Shrimp, squid, mozzarella cheese.",
      "ru": "Креветки, кальмар, сыр моцарелла.",
      "bn": "চিংড়ি, স্কুইড, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 26,
    "price": 680,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Western",
      "ru": "Пицца Вестерн",
      "bn": "পিজ্জা ওয়েস্টার্ন"
    },
    "ingredients": {
      "en": "BBQ chicken, pineapple, Tom Yum sauce, mozzarella cheese.",
      "ru": "Курица барбекю, ананас, соус Том Ям, сыр моцарелла.",
      "bn": "বারবিকিউ চিকেন, আনারস, টম ইয়াম সস, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 27,
    "price": 770,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Spicy BBQ",
      "ru": "Пицца Острый BBQ",
      "bn": "পিজ্জা স্পাইসি বারবিকিউ"
    },
    "ingredients": {
      "en": "BBQ chicken, sauce, pickled onion, mozzarella cheese.",
      "ru": "Курица барбекю, соус, маринованный лук, сыр моцарелла.",
      "bn": "বারবিকিউ চিকেন, সস, আচারি পেঁয়াজ, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 28,
    "price": 800,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Marseleza",
      "ru": "Пицца Марселеза",
      "bn": "পিজ্জা মার্সেলেজা"
    },
    "ingredients": {
      "en": "Bacon, mushrooms, onion, pickled cucumbers, mozzarella cheese.",
      "ru": "Бекон, грибы, лук, маринованные огурцы, сыр моцарелла.",
      "bn": "বেকন, মাশরুম, পেঁয়াজ, আচারি শসা, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 29,
    "price": 780,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Boss",
      "ru": "Пицца Босс",
      "bn": "পিজ্জা বস"
    },
    "ingredients": {
      "en": "Bacon, tomato, onion, grill sauce, mozzarella cheese.",
      "ru": "Бекон, помидор, лук, гриль соус, сыр моцарелла.",
      "bn": "বেকন, টমেটো, পেঁয়াজ, গ্রিল সস, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 30,
    "price": 870,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Meat Temptation",
      "ru": "Пицца Искушение Мясом",
      "bn": "পিজ্জা মিট টেম্পটেশন"
    },
    "ingredients": {
      "en": "Spicy beef, jalapeño, onion, mushrooms, mozzarella cheese.",
      "ru": "Острая говядина, халапеньо, лук, грибы, сыр моцарелла.",
      "bn": "ঝাল গরুর মাংস, জালাপেনো, পেঁয়াজ, মাশরুম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 31,
    "price": 650,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Sausages Carnival",
      "ru": "Пицца Карнавал Колбасок",
      "bn": "পিজ্জা সসেজ কার্নিভাল"
    },
    "ingredients": {
      "en": "Mixed sauce, sausages, pickled cucumbers, mozzarella cheese.",
      "ru": "Смешанный соус, колбаски, маринованные огурцы, сыр моцарелла.",
      "bn": "মিশ্র সস, সসেজ, আচারি শসা, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 32,
    "price": 650,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Capicciza Cream",
      "ru": "Пицца Капричоза Сливочная",
      "bn": "পিজ্জা কাপ্রিচোজা ক্রিম"
    },
    "ingredients": {
      "en": "Ham, mushrooms, cream, mozzarella cheese.",
      "ru": "Ветчина, грибы, сливки, сыр моцарелла.",
      "bn": "হ্যাম, মাশরুম, ক্রিম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 33,
    "price": 870,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Meat",
      "ru": "Пицца Мясная",
      "bn": "পিজ্জা মিট"
    },
    "ingredients": {
      "en": "Beef, paprika pepper, pickled onion, bell pepper, mozzarella cheese.",
      "ru": "Говядина, паприка, маринованный лук, болгарский перец, сыр моцарелла.",
      "bn": "গরুর মাংস, পাপ্রিকা, আচারি পেঁয়াজ, ক্যাপসিকাম, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 34,
    "price": 1100,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Four Season",
      "ru": "Пицца Четыре Сезона",
      "bn": "পিজ্জা ফোর সিজন"
    },
    "ingredients": {
      "en": "Mushrooms, Ham, Squid, Shrimp, Salami, Sausages, Tomatoes, mozzarella cheese.",
      "ru": "Грибы, ветчина, кальмар, креветки, салями, колбаски, помидоры, сыр моцарелла.",
      "bn": "মাশরুম, হ্যাম, স্কুইড, চিংড়ি, সালামি, সসেজ, টমেটো, মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 35,
    "price": 850,
    "size": "",
    "names": {
      "en": "Pizza Nobab-a-Dhaka",
      "ru": "Пицца Нобаб-а-Дакка",
      "bn": "পিজ্জা নবাব-এ-ঢাকা"
    },
    "ingredients": {
      "en": "Button mushrooms, pepperoni, boiled beef, onion, bell pepper and mozzarella cheese.",
      "ru": "Шампиньоны, пепперони, отварная говядина, лук, болгарский перец и сыр моцарелла.",
      "bn": "বাটন মাশরুম, পেপারোনি, সিদ্ধ গরুর মাংস, পেঁয়াজ, ক্যাপসিকাম ও মোৎসারেলা চিজ।"
    }
  },
  {
    "id": 36,
    "price": 800,
    "size": "12\", 31 cm",
    "names": {
      "en": "Pizza Sea Queen",
      "bn": "পিজ্জা সি কুইন",
      "ru": "Пицца Си Куин"
    },
    "ingredients": {
      "en": "Shrimp, tomato, BBQ sauce and mozzarella cheese.",
      "bn": "চিংড়ি, টমেটো, বারবিকিউ সস ও মোৎসারেলা চিজ।",
      "ru": "Креветки, помидор, соус барбекю и сыр моцарелла."
    }
  }
];
